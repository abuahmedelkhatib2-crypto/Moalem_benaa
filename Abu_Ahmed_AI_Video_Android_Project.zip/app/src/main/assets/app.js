let ratio='9:16', imageData='';
const $=id=>document.getElementById(id);
document.querySelectorAll('.choice').forEach(b=>b.onclick=()=>{
 document.querySelectorAll('.choice').forEach(x=>x.classList.remove('active'));
 b.classList.add('active'); ratio=b.dataset.ratio;
});
$('image').onchange=e=>{
 const f=e.target.files[0]; if(!f)return;
 const r=new FileReader(); r.onload=()=>imageData=r.result; r.readAsDataURL(f);
};
$('generate').onclick=()=>{
 const prompt=$('prompt').value.trim();
 if(!prompt){$('status').textContent='اكتب وصف الفيديو أولاً.';return}
 $('previewCard').classList.remove('hidden');
 const p=$('preview'); p.innerHTML='';
 if(imageData){const img=document.createElement('img');img.src=imageData;p.appendChild(img)}
 const box=document.createElement('div');
 box.innerHTML='<strong>'+escapeHtml($('caption').value||prompt)+'</strong><br><small>'+ratio+' • '+$('voice').value+'</small>';
 box.style.marginTop='12px';p.appendChild(box);
 $('status').textContent='تم تجهيز المعاينة. هذه النسخة تختبر التطبيق قبل ربط مولّد AI الحقيقي.';
};
$('save').onclick=()=>{
 const data={prompt:$('prompt').value,ratio,caption:$('caption').value,voice:$('voice').value};
 localStorage.setItem('abuAhmedVideoProject',JSON.stringify(data));
 $('status').textContent='تم حفظ المشروع على الهاتف.';
};
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
