# أبو أحمد AI Video

مشروع Android أولي يعمل بواجهة عربية داخل WebView.

## البناء
1. افتح المشروع في Android Studio.
2. انتظر مزامنة Gradle.
3. اختر Build > Build APK(s).
4. ستجد APK في:
   app/build/outputs/apk/debug/app-debug.apk

## مهم
هذه النسخة تحتوي على واجهة التطبيق واختبار المعاينة والحفظ المحلي.
توليد فيديو AI الحقيقي يحتاج Backend/نموذج فيديو. لا تضع أي API key سري داخل التطبيق.
